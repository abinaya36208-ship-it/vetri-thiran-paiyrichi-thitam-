from typing import Any

from app.services.platforms import get_search_url


def _money(value: float) -> float:
    return round(float(value), 2)


def _scale_price(
    budget: float,
    percentage: float,
    minimum: float,
) -> float:
    return max(
        minimum,
        _money(budget * percentage),
    )


def home_fallback(
    budget: float,
    rooms: list[str],
    style: str,
    notes: str = "",
) -> dict[str, Any]:

    rooms = rooms or ["Living Room"]

    room_count = len(rooms)

    lighting_budget = _scale_price(
        budget,
        0.12,
        500,
    )

    furniture_budget = _scale_price(
        budget,
        0.38,
        1500,
    )

    decor_budget = _scale_price(
        budget,
        0.20,
        500,
    )

    utility_budget = _scale_price(
        budget,
        0.20,
        500,
    )

    reserve_budget = _scale_price(
        budget,
        0.10,
        0,
    )

    allocations = {
        "Furniture": furniture_budget,
        "Lighting": lighting_budget,
        "Decor": decor_budget,
        "Utilities": utility_budget,
        "Reserve": reserve_budget,
    }

    items = [
        {
            "category": "Furniture",
            "name": f"{style} multi-purpose furniture set",
            "platform": "IKEA",
            "estimated_price": furniture_budget,
            "quantity": max(1, room_count),
            "reason": (
                f"Suitable for {room_count} room(s) "
                f"with a {style.lower()} style."
            ),
            "search_url": get_search_url(
                "IKEA",
                f"{style} furniture",
            ),
        },
        {
            "category": "Lighting",
            "name": "LED ceiling light set",
            "platform": "Amazon",
            "estimated_price": lighting_budget,
            "quantity": max(1, room_count),
            "reason": "Energy-efficient lighting suitable for multiple rooms.",
            "search_url": get_search_url(
                "Amazon",
                "LED ceiling light",
            ),
        },
        {
            "category": "Decor",
            "name": "Wall decor and accent pieces",
            "platform": "Flipkart",
            "estimated_price": decor_budget,
            "quantity": max(1, room_count),
            "reason": "Adds visual character without using a large portion of the budget.",
            "search_url": get_search_url(
                "Flipkart",
                "home wall decor",
            ),
        },
        {
            "category": "Utilities",
            "name": "Ceiling fan",
            "platform": "Amazon",
            "estimated_price": utility_budget,
            "quantity": max(1, room_count),
            "reason": "Practical comfort item for the planned rooms.",
            "search_url": get_search_url(
                "Amazon",
                "ceiling fan",
            ),
        },
    ]

    total = sum(
        item["estimated_price"]
        for item in items
    )

    total = min(total, budget)

    return {
        "planner_type": "home",
        "budget": _money(budget),
        "total_estimated": _money(total),
        "remaining_budget": _money(max(0, budget - total)),
        "summary": (
            f"A {style} home setup for "
            f"{', '.join(rooms)} has been planned "
            f"within the supplied budget."
        ),
        "allocations": allocations,
        "recommendations": items,
        "ai_powered": False,
    }


def party_fallback(
    budget: float,
    guests: int,
    event_type: str,
    venue: str = "",
    preferences: str = "",
) -> dict[str, Any]:

    catering = _scale_price(
        budget,
        0.45,
        guests * 150,
    )

    decoration = _scale_price(
        budget,
        0.20,
        1000,
    )

    entertainment = _scale_price(
        budget,
        0.15,
        500,
    )

    venue_budget = _scale_price(
        budget,
        0.15,
        0,
    )

    reserve = _scale_price(
        budget,
        0.05,
        0,
    )

    allocations = {
        "Catering": catering,
        "Decoration": decoration,
        "Entertainment": entertainment,
        "Venue": venue_budget,
        "Reserve": reserve,
    }

    venue_query = venue or "party venue"

    items = [
        {
            "category": "Catering",
            "name": f"{event_type} catering package",
            "platform": "Swiggy",
            "estimated_price": catering,
            "quantity": 1,
            "reason": f"Planned for approximately {guests} guests.",
            "search_url": get_search_url(
                "Swiggy",
                f"{event_type} catering",
            ),
        },
        {
            "category": "Food",
            "name": f"{event_type} food options",
            "platform": "Zomato",
            "estimated_price": catering,
            "quantity": 1,
            "reason": "Provides another food discovery option.",
            "search_url": get_search_url(
                "Zomato",
                f"{event_type} party food",
            ),
        },
        {
            "category": "Venue",
            "name": venue_query,
            "platform": "OYO",
            "estimated_price": venue_budget,
            "quantity": 1,
            "reason": "Useful for finding venue or accommodation options.",
            "search_url": get_search_url(
                "OYO",
                venue_query,
            ),
        },
        {
            "category": "Decoration",
            "name": f"{event_type} decoration package",
            "platform": "Amazon",
            "estimated_price": decoration,
            "quantity": 1,
            "reason": "Decorations selected around the event theme.",
            "search_url": get_search_url(
                "Amazon",
                f"{event_type} party decoration",
            ),
        },
    ]

    total = catering + decoration + entertainment + venue_budget

    total = min(total, budget)

    return {
        "planner_type": "party",
        "budget": _money(budget),
        "total_estimated": _money(total),
        "remaining_budget": _money(max(0, budget - total)),
        "summary": (
            f"A budget plan for a {event_type.lower()} "
            f"with approximately {guests} guests."
        ),
        "allocations": allocations,
        "recommendations": items,
        "ai_powered": False,
    }


def jewelry_fallback(
    budget: float,
    occasion: str,
    outfit_description: str,
    image_provided: bool = False,
) -> dict[str, Any]:

    earrings_budget = _scale_price(
        budget,
        0.30,
        500,
    )

    necklace_budget = _scale_price(
        budget,
        0.40,
        800,
    )

    bracelet_budget = _scale_price(
        budget,
        0.20,
        300,
    )

    reserve = _scale_price(
        budget,
        0.10,
        0,
    )

    allocations = {
        "Earrings": earrings_budget,
        "Necklace": necklace_budget,
        "Bracelet": bracelet_budget,
        "Reserve": reserve,
    }

    style_hint = (
        outfit_description.strip()
        if outfit_description.strip()
        else "your outfit"
    )

    image_note = (
        "The uploaded outfit image can be analyzed when Gemini is enabled."
        if image_provided
        else "No outfit image was supplied."
    )

    items = [
        {
            "category": "Earrings",
            "name": f"Elegant earrings for {occasion}",
            "platform": "Amazon",
            "estimated_price": earrings_budget,
            "quantity": 1,
            "reason": (
                f"Designed as a versatile match for {style_hint}. "
                f"{image_note}"
            ),
            "search_url": get_search_url(
                "Amazon",
                f"{occasion} earrings",
            ),
        },
        {
            "category": "Necklace",
            "name": f"Statement necklace for {occasion}",
            "platform": "Flipkart",
            "estimated_price": necklace_budget,
            "quantity": 1,
            "reason": (
                f"Provides a balanced centerpiece for {style_hint}."
            ),
            "search_url": get_search_url(
                "Flipkart",
                f"{occasion} necklace",
            ),
        },
        {
            "category": "Bracelet",
            "name": f"Matching bracelet for {occasion}",
            "platform": "Amazon",
            "estimated_price": bracelet_budget,
            "quantity": 1,
            "reason": "Keeps the overall jewelry combination coordinated.",
            "search_url": get_search_url(
                "Amazon",
                f"{occasion} bracelet",
            ),
        },
    ]

    total = sum(
        item["estimated_price"]
        for item in items
    )

    total = min(total, budget)

    return {
        "planner_type": "jewelry",
        "budget": _money(budget),
        "total_estimated": _money(total),
        "remaining_budget": _money(max(0, budget - total)),
        "summary": (
            f"Jewelry suggestions prepared for {occasion}. "
            f"The recommendations are kept within the supplied budget."
        ),
        "allocations": allocations,
        "recommendations": items,
        "ai_powered": False,
    }
import json
from typing import Any, Optional

from app.config import settings
from app.services.fallback import (
    home_fallback,
    jewelry_fallback,
    party_fallback,
)


def _clean_json_text(text: str) -> str:
    text = text.strip()

    if text.startswith("```"):
        lines = text.splitlines()

        if lines:
            lines = lines[1:]

        if lines and lines[-1].strip() == "```":
            lines = lines[:-1]

        text = "\n".join(lines)

    return text.strip()


def _validate_ai_response(
    data: dict[str, Any],
    planner_type: str,
    budget: float,
) -> dict[str, Any]:

    data["planner_type"] = planner_type
    data["budget"] = float(budget)

    data.setdefault("allocations", {})
    data.setdefault("recommendations", [])
    data.setdefault("summary", "AI recommendations generated.")

    total = 0.0

    cleaned_items = []

    for item in data.get("recommendations", []):
        try:
            price = float(
                item.get(
                    "estimated_price",
                    0,
                )
            )
        except (TypeError, ValueError):
            price = 0.0

        quantity = int(
            item.get(
                "quantity",
                1,
            ) or 1
        )

        total += price

        cleaned_items.append(
            {
                "category": str(
                    item.get(
                        "category",
                        "General",
                    )
                ),
                "name": str(
                    item.get(
                        "name",
                        "Recommended item",
                    )
                ),
                "platform": str(
                    item.get(
                        "platform",
                        "Amazon",
                    )
                ),
                "estimated_price": round(
                    max(price, 0),
                    2,
                ),
                "quantity": max(
                    quantity,
                    1,
                ),
                "reason": str(
                    item.get(
                        "reason",
                        "Matches the requested requirements.",
                    )
                ),
                "search_url": item.get(
                    "search_url"
                ),
            }
        )

    # Prevent accidental over-budget AI results.
    if total > budget and cleaned_items:
        scale = budget / total

        for item in cleaned_items:
            item["estimated_price"] = round(
                item["estimated_price"] * scale,
                2,
            )

        total = sum(
            item["estimated_price"]
            for item in cleaned_items
        )

    data["recommendations"] = cleaned_items
    data["total_estimated"] = round(
        min(total, budget),
        2,
    )

    data["remaining_budget"] = round(
        max(
            budget - data["total_estimated"],
            0,
        ),
        2,
    )

    data["ai_powered"] = True

    return data


def _generate_with_gemini(
    prompt: str,
    image_bytes: Optional[bytes] = None,
    mime_type: Optional[str] = None,
) -> Optional[dict[str, Any]]:

    if not settings.gemini_api_key:
        return None

    try:
        from google import genai
        from google.genai import types

        client = genai.Client(
            api_key=settings.gemini_api_key
        )

        contents: list[Any] = [prompt]

        if image_bytes:
            contents.append(
                types.Part.from_bytes(
                    data=image_bytes,
                    mime_type=mime_type or "image/jpeg",
                )
            )

        response = client.models.generate_content(
            model=settings.gemini_model,
            contents=contents,
            config=types.GenerateContentConfig(
                temperature=0.4,
                response_mime_type="application/json",
            ),
        )

        text = getattr(
            response,
            "text",
            None,
        )

        if not text:
            return None

        return json.loads(
            _clean_json_text(text)
        )

    except Exception:
        return None


def generate_home_recommendations(
    budget: float,
    rooms: list[str],
    style: str,
    notes: str = "",
) -> dict[str, Any]:

    prompt = f"""
You are PocketSmart AI, a budget-aware home interior recommendation assistant.

User budget: {budget}
Rooms: {rooms}
Preferred style: {style}
Additional notes: {notes}

Create practical recommendations for furniture, lighting, decor,
and utilities.

Return ONLY valid JSON using this structure:

{{
  "summary": "short summary",
  "allocations": {{
    "Furniture": 0,
    "Lighting": 0,
    "Decor": 0,
    "Utilities": 0,
    "Reserve": 0
  }},
  "recommendations": [
    {{
      "category": "Furniture",
      "name": "item name",
      "platform": "Amazon",
      "estimated_price": 0,
      "quantity": 1,
      "reason": "reason",
      "search_url": null
    }}
  ]
}}

Never exceed the supplied budget.
Use platforms such as Amazon, Flipkart and IKEA.
"""

    result = _generate_with_gemini(prompt)

    if result:
        return _validate_ai_response(
            result,
            "home",
            budget,
        )

    return home_fallback(
        budget=budget,
        rooms=rooms,
        style=style,
        notes=notes,
    )


def generate_party_recommendations(
    budget: float,
    guests: int,
    event_type: str,
    venue: str = "",
    preferences: str = "",
) -> dict[str, Any]:

    prompt = f"""
You are PocketSmart AI, a party budget planning assistant.

Budget: {budget}
Guests: {guests}
Event type: {event_type}
Venue: {venue}
Preferences: {preferences}

Allocate the budget across catering, decoration,
entertainment and venue.

Use platforms such as Swiggy, Zomato, OYO and Amazon.

Return ONLY valid JSON:

{{
  "summary": "short summary",
  "allocations": {{
    "Catering": 0,
    "Decoration": 0,
    "Entertainment": 0,
    "Venue": 0,
    "Reserve": 0
  }},
  "recommendations": [
    {{
      "category": "Catering",
      "name": "item",
      "platform": "Swiggy",
      "estimated_price": 0,
      "quantity": 1,
      "reason": "reason",
      "search_url": null
    }}
  ]
}}

Never exceed the supplied budget.
"""

    result = _generate_with_gemini(prompt)

    if result:
        return _validate_ai_response(
            result,
            "party",
            budget,
        )

    return party_fallback(
        budget=budget,
        guests=guests,
        event_type=event_type,
        venue=venue,
        preferences=preferences,
    )


def generate_jewelry_recommendations(
    budget: float,
    occasion: str,
    outfit_description: str,
    image_bytes: Optional[bytes] = None,
    mime_type: Optional[str] = None,
) -> dict[str, Any]:

    prompt = f"""
You are PocketSmart AI, a jewelry recommendation assistant.

Budget: {budget}
Occasion: {occasion}
Outfit description: {outfit_description}

If an outfit image is provided, analyze its broad visual characteristics
such as colors, style, formality and patterns.

Recommend coordinated earrings, necklace and bracelet options.

Return ONLY valid JSON:

{{
  "summary": "short summary",
  "allocations": {{
    "Earrings": 0,
    "Necklace": 0,
    "Bracelet": 0,
    "Reserve": 0
  }},
  "recommendations": [
    {{
      "category": "Earrings",
      "name": "item",
      "platform": "Amazon",
      "estimated_price": 0,
      "quantity": 1,
      "reason": "reason",
      "search_url": null
    }}
  ]
}}

Never exceed the supplied budget.
"""

    result = _generate_with_gemini(
        prompt,
        image_bytes=image_bytes,
        mime_type=mime_type,
    )

    if result:
        return _validate_ai_response(
            result,
            "jewelry",
            budget,
        )

    return jewelry_fallback(
        budget=budget,
        occasion=occasion,
        outfit_description=outfit_description,
        image_provided=image_bytes is not None,
    )
